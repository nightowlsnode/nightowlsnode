const sid = 'ACe691f003048dc02c4a84410887763b84';
const authorizationCode = 'Basic QUNlNjkxZjAwMzA0OGRjMDJjNGE4NDQxMDg4Nzc2M2I4NDo3MjM4YzA0YWNhNTU2MDA3MzRhNTMwYjJjNzUyZDUyNg==';
const twilioNumber = '+16467981179';
const myNumber = '+18142064914';
const GOOGLE_API_KEY = 'AIzaSyDMPrklP-kz1_UXiJyqsfidfGdSQ_Pww1s';

module.exports.sid = sid;
module.exports.authorizationCode = authorizationCode;
module.exports.twilioNumber = twilioNumber;
module.exports.myNumber = myNumber;
module.exports.GOOGLE_API_KEY = GOOGLE_API_KEY;
